const CACHE='dd-a9f5adc38198c5eb';const ASSETS=["./", "./index.apple-touch-icon.png", "./index.audio.position.worklet.js", "./index.audio.worklet.js", "./index.html", "./index.icon.png", "./index.js", "./index.pck", "./index.png", "./index.wasm"];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(ASSETS))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('dd-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{if(event.request.method!=='GET'||new URL(event.request.url).origin!==self.location.origin)return;event.respondWith(fetch(event.request).catch(()=>caches.match(event.request,{ignoreSearch:true})));});
